﻿namespace GameWebApplication.Dtos;

public enum GameStatus
{
    Release,
    Processing,
    Skipped,
    Canceled
}